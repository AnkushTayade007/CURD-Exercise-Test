package ankushTayde_start;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

import ankushTayde.student.manage.AnkushTayde_student;
import ankushTayde.student.manage.Ankush_StudentDao;

public class AnkushTayde {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws NumberFormatException, IOException, SQLException {
		// TODO Auto-generated method stub
   
		System.out.println("Welcome to Student Management App");
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		while(true)
		{
			System.out.println("PRESS 1 TO ADD ");
			System.out.println("PRESS 2 TO DISPLAY ");
			System.out.println("PRESS 3 TO UPDATE ");
			System.out.println("PRESS 4 TO DELETE");
			System.out.println("PRESS 5 TO EXIT");
			
			int c=Integer.parseInt(br.readLine());
			
			if(c==1) {
				//add student

				System.out.println("Enter Roll_no :");
				String Roll_no=br.readLine();
				
				System.out.println("Enter Name :");
				String Name=br.readLine();
				
				System.out.println("Enter contact No :");
				String Contact_Number=br.readLine();
				
				System.out.println("Enter city :");
				String City=br.readLine();
				
				System.out.println("Enter user Email ID :");
				String Email_Id=br.readLine();
				
				System.out.println("Enter user Standard :");
				String Standard=br.readLine();
				
				//create student object to store  student
				AnkushTayde_student st = new AnkushTayde_student(Name, Contact_Number, City,Email_Id, Standard);
				boolean answer=Ankush_StudentDao.insertStudentToDB(st);
				if(answer) {
					System.out.println("Record added successfully...");
				}else {
					System.out.println("something went wrong try again....");
				}
				System.out.println(st);
				
			}else if(c==2) {
				//display student
				
				Ankush_StudentDao.showAllStudent();
				
			}else if(c==3) {
				//update student
				
				System.out.println("Enter Roll_no :");
				String Roll_no=br.readLine();
				
				System.out.println("Enter Name :");
				String Name=br.readLine();
				
				System.out.println("Enter contact No :");
				String Contact_Number=br.readLine();
				
				System.out.println("Enter city :");
				String City=br.readLine();
				
				System.out.println("Enter user Email ID :");
				String Email_Id=br.readLine();
				
				System.out.println("Enter user Standard :");
				String Standard=br.readLine();
				
				//create student object to store  student
				AnkushTayde_student st = new AnkushTayde_student(Name, Contact_Number, City,Email_Id, Standard);
				boolean an=Ankush_StudentDao.UpdateRecord(st);
				if(an) {
					System.out.println("Record Updated successfully...");
				}else {
					System.out.println("something went wrong try again....");
				}
				System.out.println(st);
				
				
			}else if(c==4) {
				//delete student
				System.out.println("Enter Student Roll No to Delete:");
				int Roll_no=Integer.parseInt(br.readLine());
				boolean f=Ankush_StudentDao.deleteStudent(Roll_no);
				if(f) {
					System.out.println("Record Deleted successfully");
				}else {
					System.out.println("something went wrong try again....");
				}
				
			}else if(c==5) {
				//exit student
				
				break;
			}else {
				
			}
		}
		System.out.println("THANK YOU");
	}

}
