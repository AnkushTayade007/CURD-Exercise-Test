package ankushTayde.student.manage;

public class AnkushTayde_student {
	private int Roll_no;
	private String Name;
	private String Contact_Number;
	private String City;
	private String Email_Id;
	private String Standard;
	
	public AnkushTayde_student(String name, String contact_Number, String city, String email_Id, String standard) {
		super();
		Name = name;
		Contact_Number = contact_Number;
		City = city;
		Email_Id = email_Id;
		Standard = standard;
	}

	public AnkushTayde_student(int rollNo, String name, String contact_Number, String city, String email_Id, String standard) {
		super();
		Roll_no = rollNo;
		Name = name;
		Contact_Number = contact_Number;
		City = city;
		Email_Id = email_Id;
		Standard = standard;
	}

	public AnkushTayde_student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getRoll_no() {
		return Roll_no;
	}

	public void setRoll_no(int rollNo) {
		Roll_no = rollNo;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getContact_Number() {
		return Contact_Number;
	}

	public void setContact_Number(String contact_Number) {
		Contact_Number = contact_Number;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getEmail_Id() {
		return Email_Id;
	}

	public void setEmail_Id(String email_Id) {
		Email_Id = email_Id;
	}

	public String getStandard() {
		return Standard;
	}

	public void setStandard(String standard) {
		Standard = standard;
	}

	@Override
	public String toString() {
		return "STUDENT [Roll_no=" + Roll_no + ", Name=" + Name + ", Contact_Number=" + Contact_Number + ", City=" + City
				+ ", Email_Id=" + Email_Id + ", Standard=" + Standard + "]";
	}
	
	
}
