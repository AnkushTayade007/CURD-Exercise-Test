package ankushTayde.student.manage;

import java.sql.Connection;
import java.sql.DriverManager;

public class AnkushTayde_CP {

	static Connection con;
	
	public static Connection createC() {
		//load the driver
		try {
		Class.forName("com.mysql.jdbc.Driver");
		
		//Create the Connection ....
		String user ="root";
		String password="Vicky9850@";
		String url="jdbc:mysql://localhost:3306/student_management";
		
		con=DriverManager.getConnection(url, user, password);
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	

	

	
}
