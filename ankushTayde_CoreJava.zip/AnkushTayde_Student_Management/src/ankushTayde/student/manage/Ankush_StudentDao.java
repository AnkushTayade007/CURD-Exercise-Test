package ankushTayde.student.manage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Ankush_StudentDao {

	public static boolean insertStudentToDB(AnkushTayde_student st) {
		boolean f=false;
		//jdbc code...
		
		try {
			
			Connection con= AnkushTayde_CP.createC();
		String q="Insert into student(Name,Contact_Number,City,Email_Id,Standard) values(?,?,?,?,?)";
		//Prepared statement
		PreparedStatement pstmt=con.prepareStatement(q);
		//set the value of parameter
		pstmt.setString(1,st.getName());
		pstmt.setString(2,st.getContact_Number());
		pstmt.setString(3,st.getCity());
		pstmt.setString(4,st.getEmail_Id());
		pstmt.setString(5,st.getStandard());
		
		//execute
		pstmt.executeUpdate();
		f=true;
		
		}catch(Exception e) {
		e.printStackTrace();
	}
		return f;
	}

	public static boolean deleteStudent(int rollNo) {
		// TODO Auto-generated method stub
		boolean f=false;
		//jdbc code...
		
		try {
			
			Connection con= AnkushTayde_CP.createC();
		String q="delete from Student where Roll_no=?";
		//Prepared statement
		PreparedStatement pstmt=con.prepareStatement(q);
		//set the value of parameter
		pstmt.setInt(1,rollNo);
		
		
		//execute
		pstmt.executeUpdate();
		f=true;
		
		}catch(Exception e) {
		e.printStackTrace();
	}
		return f;
	}

	public static void showAllStudent() {
		// TODO Auto-generated method stub
		boolean f=false;
		//jdbc code...
		
		try {
			
			Connection con= AnkushTayde_CP.createC();
		String q="select * from student;";
		Statement stmt=con.createStatement();
		
		ResultSet set=stmt.executeQuery(q);
		
		while(set.next()) {
			int id=set.getInt(1);
			String name=set.getString(2);
			String contact=set.getString(3);
			String city=set.getString(4);
			String email=set.getString(5);
			String standard=set.getString(6);
			
			System.out.println(id +","+name+","+contact+","+city+","+email+","+standard);
			
			System.out.println("*************************************");
			
		}
		
		
		}catch(Exception e) {
		e.printStackTrace();
	}
		
	}

	public static boolean UpdateRecord(AnkushTayde_student st) throws SQLException {
		boolean f = false;
		// TODO Auto-generated method stub
		try {
		Connection con= AnkushTayde_CP.createC();
		String str="Insert into student(Name,Contact_Number,City,Email_Id,Standard) values(?,?,?,?,?)";
		PreparedStatement pst=con.prepareStatement(str);
		

		pst.setString(1,st.getName());
		pst.setString(2, st.getContact_Number());
		pst.setString(3, st.getCity());
		pst.setString(4, st.getEmail_Id());
		pst.setString(5, st.getStandard());
		
		pst.executeUpdate();
       f=true;
		
		}catch(Exception e) {
		e.printStackTrace();
	}
		return f;
		
	}

	
}
